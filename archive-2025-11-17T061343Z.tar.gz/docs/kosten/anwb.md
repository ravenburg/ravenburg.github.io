# ANWB

De ANWB hanteert de volgende prijzen voor de diensten die zij leveren.

## Categoriën

Bij de anwb worden verschillende categorieën gehanteerd hier onder zijn deze te vinden.

|Categorie| omschrijving |
|:-------:|------------|
| Categorie 1 |Lakschade, Wagen kan niet meer getuned worden, orange motorlampje |
| Categorie 2 |koplamp(en) en of achterlamp(en) stuk, kleine deuken, Eén of twee ramen kapot, Eén lekke band.|
| Categorie 3 | Grote deuken, Meer dan twee ramen kapot, meerdere banden lek, twee deuren weg, motorkap/kofferklep weg|
| Categorie 4 | Meer dan twee deuren weg, vervorming van het frame, Rood motorlampje |
| Categorie 5 | De auto rijd maar rookt hevig, zwaar beschadigd (alle deuren en motorkap en kofferklep zijn van voertuig) |
| Categorie 6 | De auto is total loss (shift + e om de wagen te duwen)|

## Motor

| Categorie | Hoofdbureau | In de stad | Buiten de stad |
|:---------:|:-----------:|:----------:|:--------------:|
|Categorie 1| € 225,- | € 375,- | € 425,- |
|Categorie 2| € 300,- | € 450,- | € 500,- |
|Categorie 3| € 400,- | € 550,- | € 600,- |
|Categorie 4| € 500,- | € 650,- | € 700,- |
|Categorie 5| € 600,- | € 750,- | € 800,- |
|Categorie 6| € 750,- | € 900,- | € 950,- |

## Auto's en boten

| Categorie | Hoofdbureau | In de stad | Buiten de stad |
|:---------:|:-----------:|:----------:|:--------------:|
|Categorie 1| € 450,- | € 750,- | € 850,- |
|Categorie 2| € 600,- | € 900,- | € 1000,- |
|Categorie 3| € 800,- | € 1100,- | € 1200,- |
|Categorie 4| € 1000,- | € 1300,- | € 1400,- |
|Categorie 5| € 1200,- | € 1500,- | € 1600,- |
|Categorie 7| € 1500,- | € 1800,- | € 1900,- |

## Helikopters en vliegtuigen

| Categorie | Prijs |
|:---------:|:-----------:|
|Categorie 1| € 900,- |
|Categorie 2| € 1200,- |
|Categorie 3| € 1600,- |
|Categorie 4| € 2000,- |
|Categorie 5| € 2400,- |
|Categorie 7| € 3000,- |

## Extra's

| Dienst | Prijs |
|:---------|:-----------:|
| Brandblusser | € 2500,- |
| Schoonmaken | € 50,- |
| Takelkosten | € 500,- |
| Afleverkosten | € 500,- |
| Kleine benzine bijvullen | € 125,- |
| Grote benzine bijvullen | € 250,- |

!!! attention "LET OP"
    De prijzen kunnen ten alle tijden worden worden gewijzigd
